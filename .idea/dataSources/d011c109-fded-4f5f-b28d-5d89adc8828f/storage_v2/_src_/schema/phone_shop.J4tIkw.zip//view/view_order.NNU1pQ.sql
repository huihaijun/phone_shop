create definer = root@`%` view view_order as
select `phone_shop`.`s_orderitem`.`itemId`   AS `itemId`,
       `phone_shop`.`s_orderitem`.`bookId`   AS `bookId`,
       `phone_shop`.`s_orderitem`.`quantity` AS `quantity`,
       `phone_shop`.`s_order`.`orderId`      AS `orderId`,
       `phone_shop`.`s_order`.`orderNum`     AS `orderNum`,
       `phone_shop`.`s_order`.`userId`       AS `userId`,
       `phone_shop`.`s_order`.`orderDate`    AS `orderDate`,
       `phone_shop`.`s_order`.`money`        AS `money`,
       `phone_shop`.`s_order`.`orderStatus`  AS `orderStatus`
from (`phone_shop`.`s_order` join `phone_shop`.`s_orderitem`
      on ((`phone_shop`.`s_orderitem`.`orderId` = `phone_shop`.`s_order`.`orderId`)));

